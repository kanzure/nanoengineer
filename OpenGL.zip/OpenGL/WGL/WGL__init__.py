# This file was created automatically by SWIG.
import WGL__init___
class PIXELFORMATDESCRIPTOR:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,PIXELFORMATDESCRIPTOR):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = PIXELFORMATDESCRIPTOR.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = PIXELFORMATDESCRIPTOR.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["nSize"] = WGL__init___.PIXELFORMATDESCRIPTOR_nSize_set
    __getmethods__["nSize"] = WGL__init___.PIXELFORMATDESCRIPTOR_nSize_get
    __setmethods__["nVersion"] = WGL__init___.PIXELFORMATDESCRIPTOR_nVersion_set
    __getmethods__["nVersion"] = WGL__init___.PIXELFORMATDESCRIPTOR_nVersion_get
    __setmethods__["dwFlags"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwFlags_set
    __getmethods__["dwFlags"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwFlags_get
    __setmethods__["iPixelType"] = WGL__init___.PIXELFORMATDESCRIPTOR_iPixelType_set
    __getmethods__["iPixelType"] = WGL__init___.PIXELFORMATDESCRIPTOR_iPixelType_get
    __setmethods__["cColorBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cColorBits_set
    __getmethods__["cColorBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cColorBits_get
    __setmethods__["cRedBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cRedBits_set
    __getmethods__["cRedBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cRedBits_get
    __setmethods__["cRedShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cRedShift_set
    __getmethods__["cRedShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cRedShift_get
    __setmethods__["cGreenBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cGreenBits_set
    __getmethods__["cGreenBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cGreenBits_get
    __setmethods__["cGreenShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cGreenShift_set
    __getmethods__["cGreenShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cGreenShift_get
    __setmethods__["cBlueBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cBlueBits_set
    __getmethods__["cBlueBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cBlueBits_get
    __setmethods__["cBlueShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cBlueShift_set
    __getmethods__["cBlueShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cBlueShift_get
    __setmethods__["cAlphaBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAlphaBits_set
    __getmethods__["cAlphaBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAlphaBits_get
    __setmethods__["cAlphaShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAlphaShift_set
    __getmethods__["cAlphaShift"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAlphaShift_get
    __setmethods__["cAccumBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumBits_set
    __getmethods__["cAccumBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumBits_get
    __setmethods__["cAccumRedBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumRedBits_set
    __getmethods__["cAccumRedBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumRedBits_get
    __setmethods__["cAccumGreenBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumGreenBits_set
    __getmethods__["cAccumGreenBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumGreenBits_get
    __setmethods__["cAccumBlueBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumBlueBits_set
    __getmethods__["cAccumBlueBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumBlueBits_get
    __setmethods__["cAccumAlphaBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumAlphaBits_set
    __getmethods__["cAccumAlphaBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAccumAlphaBits_get
    __setmethods__["cDepthBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cDepthBits_set
    __getmethods__["cDepthBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cDepthBits_get
    __setmethods__["cStencilBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cStencilBits_set
    __getmethods__["cStencilBits"] = WGL__init___.PIXELFORMATDESCRIPTOR_cStencilBits_get
    __setmethods__["cAuxBuffers"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAuxBuffers_set
    __getmethods__["cAuxBuffers"] = WGL__init___.PIXELFORMATDESCRIPTOR_cAuxBuffers_get
    __setmethods__["iLayerType"] = WGL__init___.PIXELFORMATDESCRIPTOR_iLayerType_set
    __getmethods__["iLayerType"] = WGL__init___.PIXELFORMATDESCRIPTOR_iLayerType_get
    __setmethods__["bReserved"] = WGL__init___.PIXELFORMATDESCRIPTOR_bReserved_set
    __getmethods__["bReserved"] = WGL__init___.PIXELFORMATDESCRIPTOR_bReserved_get
    __setmethods__["dwLayerMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwLayerMask_set
    __getmethods__["dwLayerMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwLayerMask_get
    __setmethods__["dwVisibleMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwVisibleMask_set
    __getmethods__["dwVisibleMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwVisibleMask_get
    __setmethods__["dwDamageMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwDamageMask_set
    __getmethods__["dwDamageMask"] = WGL__init___.PIXELFORMATDESCRIPTOR_dwDamageMask_get
    def __init__(self,*args):
        self.this = apply(WGL__init___.new_PIXELFORMATDESCRIPTOR,args)
        self.thisown = 1
    def __del__(self, destroy= WGL__init___.delete_PIXELFORMATDESCRIPTOR):
        if getattr(self,'thisown',0):
            destroy(self)
    def __repr__(self):
        return "<C PIXELFORMATDESCRIPTOR instance at %s>" % (self.this,)

class PIXELFORMATDESCRIPTORPtr(PIXELFORMATDESCRIPTOR):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = PIXELFORMATDESCRIPTOR
WGL__init___.PIXELFORMATDESCRIPTOR_swigregister(PIXELFORMATDESCRIPTORPtr)
class POINTFLOAT:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,POINTFLOAT):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = POINTFLOAT.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = POINTFLOAT.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["x"] = WGL__init___.POINTFLOAT_x_set
    __getmethods__["x"] = WGL__init___.POINTFLOAT_x_get
    __setmethods__["y"] = WGL__init___.POINTFLOAT_y_set
    __getmethods__["y"] = WGL__init___.POINTFLOAT_y_get
    def __init__(self,*args):
        self.this = apply(WGL__init___.new_POINTFLOAT,args)
        self.thisown = 1
    def __del__(self, destroy= WGL__init___.delete_POINTFLOAT):
        if getattr(self,'thisown',0):
            destroy(self)
    def __repr__(self):
        return "<C POINTFLOAT instance at %s>" % (self.this,)

class POINTFLOATPtr(POINTFLOAT):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = POINTFLOAT
WGL__init___.POINTFLOAT_swigregister(POINTFLOATPtr)
class GLYPHMETRICSFLOAT:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,GLYPHMETRICSFLOAT):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = GLYPHMETRICSFLOAT.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = GLYPHMETRICSFLOAT.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["gmfBlackBoxX"] = WGL__init___.GLYPHMETRICSFLOAT_gmfBlackBoxX_set
    __getmethods__["gmfBlackBoxX"] = WGL__init___.GLYPHMETRICSFLOAT_gmfBlackBoxX_get
    __setmethods__["gmfBlackBoxY"] = WGL__init___.GLYPHMETRICSFLOAT_gmfBlackBoxY_set
    __getmethods__["gmfBlackBoxY"] = WGL__init___.GLYPHMETRICSFLOAT_gmfBlackBoxY_get
    __setmethods__["gmfptGlyphOrigin"] = WGL__init___.GLYPHMETRICSFLOAT_gmfptGlyphOrigin_set
    __getmethods__["gmfptGlyphOrigin"] = WGL__init___.GLYPHMETRICSFLOAT_gmfptGlyphOrigin_get
    __setmethods__["gmfCellIncX"] = WGL__init___.GLYPHMETRICSFLOAT_gmfCellIncX_set
    __getmethods__["gmfCellIncX"] = WGL__init___.GLYPHMETRICSFLOAT_gmfCellIncX_get
    __setmethods__["gmfCellIncY"] = WGL__init___.GLYPHMETRICSFLOAT_gmfCellIncY_set
    __getmethods__["gmfCellIncY"] = WGL__init___.GLYPHMETRICSFLOAT_gmfCellIncY_get
    def __init__(self,*args):
        self.this = apply(WGL__init___.new_GLYPHMETRICSFLOAT,args)
        self.thisown = 1
    def __del__(self, destroy= WGL__init___.delete_GLYPHMETRICSFLOAT):
        if getattr(self,'thisown',0):
            destroy(self)
    def __repr__(self):
        return "<C GLYPHMETRICSFLOAT instance at %s>" % (self.this,)

class GLYPHMETRICSFLOATPtr(GLYPHMETRICSFLOAT):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = GLYPHMETRICSFLOAT
WGL__init___.GLYPHMETRICSFLOAT_swigregister(GLYPHMETRICSFLOATPtr)
class LAYERPLANEDESCRIPTOR:
    __setmethods__ = {}
    for _s in []: __setmethods__.update(_s.__setmethods__)
    def __setattr__(self,name,value):
        if (name == "this"):
            if isinstance(value,LAYERPLANEDESCRIPTOR):
                self.__dict__[name] = value.this
                if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
                del value.thisown
                return
        method = LAYERPLANEDESCRIPTOR.__setmethods__.get(name,None)
        if method: return method(self,value)
        self.__dict__[name] = value

    __getmethods__ = {}
    for _s in []: __getmethods__.update(_s.__getmethods__)
    def __getattr__(self,name):
        method = LAYERPLANEDESCRIPTOR.__getmethods__.get(name,None)
        if method: return method(self)
        raise AttributeError,name

    __setmethods__["nSize"] = WGL__init___.LAYERPLANEDESCRIPTOR_nSize_set
    __getmethods__["nSize"] = WGL__init___.LAYERPLANEDESCRIPTOR_nSize_get
    __setmethods__["nVersion"] = WGL__init___.LAYERPLANEDESCRIPTOR_nVersion_set
    __getmethods__["nVersion"] = WGL__init___.LAYERPLANEDESCRIPTOR_nVersion_get
    __setmethods__["dwFlags"] = WGL__init___.LAYERPLANEDESCRIPTOR_dwFlags_set
    __getmethods__["dwFlags"] = WGL__init___.LAYERPLANEDESCRIPTOR_dwFlags_get
    __setmethods__["iPixelType"] = WGL__init___.LAYERPLANEDESCRIPTOR_iPixelType_set
    __getmethods__["iPixelType"] = WGL__init___.LAYERPLANEDESCRIPTOR_iPixelType_get
    __setmethods__["cColorBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cColorBits_set
    __getmethods__["cColorBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cColorBits_get
    __setmethods__["cRedBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cRedBits_set
    __getmethods__["cRedBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cRedBits_get
    __setmethods__["cRedShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cRedShift_set
    __getmethods__["cRedShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cRedShift_get
    __setmethods__["cGreenBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cGreenBits_set
    __getmethods__["cGreenBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cGreenBits_get
    __setmethods__["cGreenShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cGreenShift_set
    __getmethods__["cGreenShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cGreenShift_get
    __setmethods__["cBlueBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cBlueBits_set
    __getmethods__["cBlueBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cBlueBits_get
    __setmethods__["cBlueShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cBlueShift_set
    __getmethods__["cBlueShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cBlueShift_get
    __setmethods__["cAlphaBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAlphaBits_set
    __getmethods__["cAlphaBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAlphaBits_get
    __setmethods__["cAlphaShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAlphaShift_set
    __getmethods__["cAlphaShift"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAlphaShift_get
    __setmethods__["cAccumBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumBits_set
    __getmethods__["cAccumBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumBits_get
    __setmethods__["cAccumRedBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumRedBits_set
    __getmethods__["cAccumRedBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumRedBits_get
    __setmethods__["cAccumGreenBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumGreenBits_set
    __getmethods__["cAccumGreenBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumGreenBits_get
    __setmethods__["cAccumBlueBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumBlueBits_set
    __getmethods__["cAccumBlueBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumBlueBits_get
    __setmethods__["cAccumAlphaBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumAlphaBits_set
    __getmethods__["cAccumAlphaBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAccumAlphaBits_get
    __setmethods__["cDepthBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cDepthBits_set
    __getmethods__["cDepthBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cDepthBits_get
    __setmethods__["cStencilBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cStencilBits_set
    __getmethods__["cStencilBits"] = WGL__init___.LAYERPLANEDESCRIPTOR_cStencilBits_get
    __setmethods__["cAuxBuffers"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAuxBuffers_set
    __getmethods__["cAuxBuffers"] = WGL__init___.LAYERPLANEDESCRIPTOR_cAuxBuffers_get
    __setmethods__["iLayerPlane"] = WGL__init___.LAYERPLANEDESCRIPTOR_iLayerPlane_set
    __getmethods__["iLayerPlane"] = WGL__init___.LAYERPLANEDESCRIPTOR_iLayerPlane_get
    __setmethods__["bReserved"] = WGL__init___.LAYERPLANEDESCRIPTOR_bReserved_set
    __getmethods__["bReserved"] = WGL__init___.LAYERPLANEDESCRIPTOR_bReserved_get
    __setmethods__["crTransparent"] = WGL__init___.LAYERPLANEDESCRIPTOR_crTransparent_set
    __getmethods__["crTransparent"] = WGL__init___.LAYERPLANEDESCRIPTOR_crTransparent_get
    def __init__(self,*args):
        self.this = apply(WGL__init___.new_LAYERPLANEDESCRIPTOR,args)
        self.thisown = 1
    def __del__(self, destroy= WGL__init___.delete_LAYERPLANEDESCRIPTOR):
        if getattr(self,'thisown',0):
            destroy(self)
    def __repr__(self):
        return "<C LAYERPLANEDESCRIPTOR instance at %s>" % (self.this,)

class LAYERPLANEDESCRIPTORPtr(LAYERPLANEDESCRIPTOR):
    def __init__(self,this):
        self.this = this
        if not hasattr(self,"thisown"): self.thisown = 0
        self.__class__ = LAYERPLANEDESCRIPTOR
WGL__init___.LAYERPLANEDESCRIPTOR_swigregister(LAYERPLANEDESCRIPTORPtr)
wglUseFontBitmaps = WGL__init___.wglUseFontBitmapsA


wglUseFontOutlines = WGL__init___.wglUseFontOutlinesA


def __info():
	return []


__api_version__ = WGL__init___.__api_version__
__author__ = WGL__init___.__author__
__date__ = WGL__init___.__date__
__doc__ = WGL__init___.__doc__
__version__ = WGL__init___.__version__


__version__ = WGL__init___.__version__
__date__ = WGL__init___.__date__
__api_version__ = WGL__init___.__api_version__
__author__ = WGL__init___.__author__
__doc__ = WGL__init___.__doc__
PFD_TYPE_RGBA = WGL__init___.PFD_TYPE_RGBA
PFD_TYPE_COLORINDEX = WGL__init___.PFD_TYPE_COLORINDEX
PFD_MAIN_PLANE = WGL__init___.PFD_MAIN_PLANE
PFD_OVERLAY_PLANE = WGL__init___.PFD_OVERLAY_PLANE
PFD_UNDERLAY_PLANE = WGL__init___.PFD_UNDERLAY_PLANE
PFD_DOUBLEBUFFER = WGL__init___.PFD_DOUBLEBUFFER
PFD_STEREO = WGL__init___.PFD_STEREO
PFD_DRAW_TO_WINDOW = WGL__init___.PFD_DRAW_TO_WINDOW
PFD_DRAW_TO_BITMAP = WGL__init___.PFD_DRAW_TO_BITMAP
PFD_SUPPORT_GDI = WGL__init___.PFD_SUPPORT_GDI
PFD_SUPPORT_OPENGL = WGL__init___.PFD_SUPPORT_OPENGL
PFD_GENERIC_FORMAT = WGL__init___.PFD_GENERIC_FORMAT
PFD_NEED_PALETTE = WGL__init___.PFD_NEED_PALETTE
PFD_NEED_SYSTEM_PALETTE = WGL__init___.PFD_NEED_SYSTEM_PALETTE
PFD_SWAP_EXCHANGE = WGL__init___.PFD_SWAP_EXCHANGE
PFD_SWAP_COPY = WGL__init___.PFD_SWAP_COPY
PFD_SWAP_LAYER_BUFFERS = WGL__init___.PFD_SWAP_LAYER_BUFFERS
PFD_GENERIC_ACCELERATED = WGL__init___.PFD_GENERIC_ACCELERATED
PFD_SUPPORT_DIRECTDRAW = WGL__init___.PFD_SUPPORT_DIRECTDRAW
PFD_DEPTH_DONTCARE = WGL__init___.PFD_DEPTH_DONTCARE
PFD_DOUBLEBUFFER_DONTCARE = WGL__init___.PFD_DOUBLEBUFFER_DONTCARE
PFD_STEREO_DONTCARE = WGL__init___.PFD_STEREO_DONTCARE
WGL_FONT_LINES = WGL__init___.WGL_FONT_LINES
WGL_FONT_POLYGONS = WGL__init___.WGL_FONT_POLYGONS
LPD_DOUBLEBUFFER = WGL__init___.LPD_DOUBLEBUFFER
LPD_STEREO = WGL__init___.LPD_STEREO
LPD_SUPPORT_GDI = WGL__init___.LPD_SUPPORT_GDI
LPD_SUPPORT_OPENGL = WGL__init___.LPD_SUPPORT_OPENGL
LPD_SHARE_DEPTH = WGL__init___.LPD_SHARE_DEPTH
LPD_SHARE_STENCIL = WGL__init___.LPD_SHARE_STENCIL
LPD_SHARE_ACCUM = WGL__init___.LPD_SHARE_ACCUM
LPD_SWAP_EXCHANGE = WGL__init___.LPD_SWAP_EXCHANGE
LPD_SWAP_COPY = WGL__init___.LPD_SWAP_COPY
LPD_TRANSPARENT = WGL__init___.LPD_TRANSPARENT
LPD_TYPE_RGBA = WGL__init___.LPD_TYPE_RGBA
LPD_TYPE_COLORINDEX = WGL__init___.LPD_TYPE_COLORINDEX
WGL_SWAP_MAIN_PLANE = WGL__init___.WGL_SWAP_MAIN_PLANE
WGL_SWAP_OVERLAY1 = WGL__init___.WGL_SWAP_OVERLAY1
WGL_SWAP_OVERLAY2 = WGL__init___.WGL_SWAP_OVERLAY2
WGL_SWAP_OVERLAY3 = WGL__init___.WGL_SWAP_OVERLAY3
WGL_SWAP_OVERLAY4 = WGL__init___.WGL_SWAP_OVERLAY4
WGL_SWAP_OVERLAY5 = WGL__init___.WGL_SWAP_OVERLAY5
WGL_SWAP_OVERLAY6 = WGL__init___.WGL_SWAP_OVERLAY6
WGL_SWAP_OVERLAY7 = WGL__init___.WGL_SWAP_OVERLAY7
WGL_SWAP_OVERLAY8 = WGL__init___.WGL_SWAP_OVERLAY8
WGL_SWAP_OVERLAY9 = WGL__init___.WGL_SWAP_OVERLAY9
WGL_SWAP_OVERLAY10 = WGL__init___.WGL_SWAP_OVERLAY10
WGL_SWAP_OVERLAY11 = WGL__init___.WGL_SWAP_OVERLAY11
WGL_SWAP_OVERLAY12 = WGL__init___.WGL_SWAP_OVERLAY12
WGL_SWAP_OVERLAY13 = WGL__init___.WGL_SWAP_OVERLAY13
WGL_SWAP_OVERLAY14 = WGL__init___.WGL_SWAP_OVERLAY14
WGL_SWAP_OVERLAY15 = WGL__init___.WGL_SWAP_OVERLAY15
WGL_SWAP_UNDERLAY1 = WGL__init___.WGL_SWAP_UNDERLAY1
WGL_SWAP_UNDERLAY2 = WGL__init___.WGL_SWAP_UNDERLAY2
WGL_SWAP_UNDERLAY3 = WGL__init___.WGL_SWAP_UNDERLAY3
WGL_SWAP_UNDERLAY4 = WGL__init___.WGL_SWAP_UNDERLAY4
WGL_SWAP_UNDERLAY5 = WGL__init___.WGL_SWAP_UNDERLAY5
WGL_SWAP_UNDERLAY6 = WGL__init___.WGL_SWAP_UNDERLAY6
WGL_SWAP_UNDERLAY7 = WGL__init___.WGL_SWAP_UNDERLAY7
WGL_SWAP_UNDERLAY8 = WGL__init___.WGL_SWAP_UNDERLAY8
WGL_SWAP_UNDERLAY9 = WGL__init___.WGL_SWAP_UNDERLAY9
WGL_SWAP_UNDERLAY10 = WGL__init___.WGL_SWAP_UNDERLAY10
WGL_SWAP_UNDERLAY11 = WGL__init___.WGL_SWAP_UNDERLAY11
WGL_SWAP_UNDERLAY12 = WGL__init___.WGL_SWAP_UNDERLAY12
WGL_SWAP_UNDERLAY13 = WGL__init___.WGL_SWAP_UNDERLAY13
WGL_SWAP_UNDERLAY14 = WGL__init___.WGL_SWAP_UNDERLAY14
WGL_SWAP_UNDERLAY15 = WGL__init___.WGL_SWAP_UNDERLAY15
ChoosePixelFormat = WGL__init___.ChoosePixelFormat

DescribePixelFormat = WGL__init___.DescribePixelFormat

GetPixelFormat = WGL__init___.GetPixelFormat

SetPixelFormat = WGL__init___.SetPixelFormat

SwapBuffers = WGL__init___.SwapBuffers

wglCreateContext = WGL__init___.wglCreateContext

wglCreateLayerContext = WGL__init___.wglCreateLayerContext

wglCopyContext = WGL__init___.wglCopyContext

wglDeleteContext = WGL__init___.wglDeleteContext

wglDescribeLayerPlane = WGL__init___.wglDescribeLayerPlane

wglGetCurrentContext = WGL__init___.wglGetCurrentContext

wglGetCurrentDC = WGL__init___.wglGetCurrentDC

wglGetLayerPaletteEntries = WGL__init___.wglGetLayerPaletteEntries

wglGetProcAddress = WGL__init___.wglGetProcAddress

wglMakeCurrent = WGL__init___.wglMakeCurrent

wglRealizeLayerPalette = WGL__init___.wglRealizeLayerPalette

wglSetLayerPaletteEntries = WGL__init___.wglSetLayerPaletteEntries

wglShareLists = WGL__init___.wglShareLists

wglSwapLayerBuffers = WGL__init___.wglSwapLayerBuffers

wglUseFontBitmapsA = WGL__init___.wglUseFontBitmapsA

wglUseFontBitmapsW = WGL__init___.wglUseFontBitmapsW

wglUseFontOutlinesA = WGL__init___.wglUseFontOutlinesA

wglUseFontOutlinesW = WGL__init___.wglUseFontOutlinesW


